﻿namespace MyGymProgressApi.Data.Models
{
    public class Performance
    {
    }
}
